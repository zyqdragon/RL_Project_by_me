import gymnasium as gym
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
import torch
import copy

## 创建一个游戏环境
#env = gym.make("CartPole-v1",render_mode="rgb_array")
env = gym.make("CartPole-v1",render_mode="human")
print("-----------------------env.action_space=", env.action_space)
print("---------- env.observation_space=", env. observation_space)
observation=[0, 0, 0, 0]
## 训练20个epoch

class Q_Net(nn.Module):
    def __init__(self, state_dim, action_dim, hid_shape):
        super(Q_Net, self).__init__()
        print("-----------state_dim=",state_dim,"-------hid_shape=",hid_shape,"--------action_dim=",action_dim)
        self.fc1 = nn.Linear(state_dim, hid_shape)
        self.fc2 = nn.Linear(hid_shape, hid_shape)
        self.fc3 = nn.Linear(hid_shape, action_dim)
        self.identity = nn.Identity()  # 使用 nn.Identity()
    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        x = self.fc3(x)
        out = self.identity(x)
        return out
state_dim=4
action_dim=2
net_width=90
q_net = Q_Net(state_dim,action_dim,net_width)
q_net.load_state_dict(torch.load("./model/DQN_CPV1_600.pth",map_location='cpu'))

for i in range(200):
    idx=0    
    ## 每次训练前都初始化环境
    env.reset()
    ## 与环境的最大交互次数为100
    for step in range(8000):
        idx=idx+1
        ## 渲染环境        
        env.render()
        ## 从 action 空间中获取一个 action
        action = env.action_space.sample()
        with torch.no_grad():
            # state = torch.FloatTensor(observation.reshape(1, -1))
            state = torch.FloatTensor(observation)
            action = q_net(state).argmax().item()
        print("-----------action=",action)
        ## 根据 action 与环境进运行一次交互
        observation,reward,done,info,_ = env.step(action)
        print("**----idx=",idx,"--observation=",observation,"--reward=",reward,"---done=",done)        
        ## 如果返回当前游戏结束，推出当前游戏继续下一次训练
        if(done):
            print("                                                     ")
            print("                                                     ")            
            idx=0
            break

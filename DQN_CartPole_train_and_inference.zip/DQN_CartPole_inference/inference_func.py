from datetime import datetime
from DQN import DQN_agent
import gymnasium as gym
import os, shutil
import argparse
import torch

def evaluate_policy(env, agent, turns = 3):
    total_scores = 0
    for j in range(turns):
        s, info = env.reset()
        done = False
        while not done:
            # Take deterministic actions at test time
            a = agent.select_action(s, deterministic=True)
            s_next, r, dw, tr, info = env.step(a)
            done = (dw or tr)
            total_scores += r
            s = s_next
    return int(total_scores/turns)

parser = argparse.ArgumentParser()
opt = parser.parse_args()

def main():
    EnvName = 'CartPole-v1'
    BriefEnvName = 'CPV1'
    env = gym.make(EnvName, render_mode = "human")
    opt.lr = 1e-4
    opt.net_width = 90
    opt.ModelIdex = 1000
    opt.state_dim = env.observation_space.shape[0]
    opt.action_dim = env.action_space.n 
    opt.dvc = torch.device('cpu') # from str to torch.device   
    print(opt)
    #Algorithm Setting
    algo_name = 'DQN'
    # Seed Everything
    print('Algorithm:',algo_name,'Env:',BriefEnvName,'state_dim:',opt.state_dim,'action_dim:',opt.action_dim,'\n')
    # define the model and load the parameters of the model
    agent = DQN_agent(**vars(opt))
    agent.load(algo_name,BriefEnvName,opt.ModelIdex)

    while True:
        score = evaluate_policy(env, agent, 1)
        print('EnvName:', BriefEnvName,'score:', score)
    env.close()

if __name__ == '__main__':
    main()
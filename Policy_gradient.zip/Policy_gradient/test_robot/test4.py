import gym
import time
# env=gym.make('CartPole-v1')
env = gym.make('FetchPush-v1')
env.reset()
a=env.action_space
print(a)
o=env.observation_space
print(o)
print(env.goal)
action=env.action_space.sample()
len_time=2
print("--------step0------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0,0,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step1------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step2------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step3------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step4------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step5------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step6------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step7------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step8------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step9------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step10------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)
print("--------step11------")
env.render() # 可视化环境状态（需要环境支持渲染）
action=[0.9,0.3,0,0]
observations , reward , done , info=env.step(action)
print("------observations",observations)
time.sleep(len_time)

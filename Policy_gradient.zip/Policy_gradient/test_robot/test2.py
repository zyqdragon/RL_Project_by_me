import gym
env = gym.make('FetchPush-v1')
print("---------env=",env)
env.reset()
idx=0
for _ in range(1000):
  idx=(idx+1)%500
  print("----idx=",idx,"----------env.action_space=",env.action_space)
  #r,action,dw,f=env.step(env.action_space.sample()) # take a random action
  action = env.action_space.sample()  # 随机生成动作
  observation, reward, done, info = env.step(action)  # 执行动作并获取反馈
  print("--------------action=",action,"---reward=",reward)
  print("------observation_observation=",observation["observation"])
  print("------observation_achieved_goal=",observation["achieved_goal"])
  print("------observation_desired_goal=",observation["desired_goal"])
  env.render() # 可视化环境状态（需要环境支持渲染）
  if done:
     break

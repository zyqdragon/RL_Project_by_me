import gym
env = gym.make('FetchPush-v1')
print("---------env=",env)
env.reset()
for _ in range(1000):
  print("----------env.action_space=",env.action_space)
  env.render()
  r,action,dw,f=env.step(env.action_space.sample()) # take a random action
# https://blog.csdn.net/bornfree5511/article/details/107341116
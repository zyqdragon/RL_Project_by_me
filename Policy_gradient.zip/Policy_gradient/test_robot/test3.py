import gym
import time
# env=gym.make('CartPole-v1')
env = gym.make('FetchPush-v1')
env.render() # 可视化环境状态（需要环境支持渲染）
env.reset()
print(env.goal)
action=[0, 0,0,0]
a=env.action_space
print(a)
o=env.observation_space
print(o)
observations , reward , done , info=env.step(action)
print(observations['observation'])
action=env.action_space.sample()
action=[0, 0,0,0]
print("------action=",action)
observations , reward , done , info=env.step(action)
print(observations['observation'])
time.sleep(9)
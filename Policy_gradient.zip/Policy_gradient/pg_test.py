import gymnasium as gym
# import gym
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt


# 定义策略网络
class PolicyNet(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
            nn.Softmax(dim=-1)
        )
    def forward(self, x):
        return self.net(x)
#check

env = gym.make('CartPole-v1', render_mode="human")
input_dim = env.observation_space.shape[0]
output_dim = env.action_space.n
state, info = env.reset()
state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
ttm=PolicyNet(input_dim, output_dim)
ttm.load_state_dict(torch.load("./cartpole_PG_model.pth"))
# targ........................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................et_net = torch.load("f4.pth")
ttm.eval()
 
def getaction(state):
    with torch.no_grad():
        g = ttm(state).max(1)[1]
        g = g.view(1, 1)
        return g
 
totalreward = 0
while True:
    action = getaction(state)
    observation, reward, done, _, _ = env.step(action.item())
    totalreward += reward
    print("-----------totalreward=",totalreward)
    next_state = torch.tensor(observation, dtype=torch.float32, device="cpu").unsqueeze(0)
    state = next_state 
    if done:
        break
 
print(totalreward)
#https://blog.csdn.net/weixin_43949898/article/details/140172626
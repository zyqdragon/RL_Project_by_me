import gymnasium as gym
# import gym
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import numpy as np

# 定义策略网络
class PolicyNet(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, x):
        return self.net(x)
# 初始化环境
env = gym.make("CartPole-v1")
input_dim = env.observation_space.shape[0]
output_dim = env.action_space.n
print("-----input_dim=",input_dim,"---output_dim=",output_dim)
# 创建策略网络和优化器
policy_net = PolicyNet(input_dim, output_dim)
optimizer = optim.Adam(policy_net.parameters(), lr=1e-2)
# 设置超参数
num_episodes = 800  # 训练轮数
gamma = 0.99  # 折扣因子
# 用于记录每个episode的总奖励
episode_rewards = []
# REINFORCE算法：收集一个episode的数据，然后在episode结束后更新策略
for episode in range(num_episodes):
    state, _ = env.reset()  # 重置环境并获取初始状态，返回值为 (state, info)
    log_probs = []  # 记录每一步动作的对数概率
    rewards = []  # 记录每一步获得的奖励
    total_reward = 0
    done = False
    while not done:
        state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        # print("------state_tensor=",state_tensor)
        # 前向传播，获得当前状态下各动作的概率分布
        action_probs = policy_net(state_tensor)
        
        # 根据概率分布采样动作
        action_distribution = torch.distributions.Categorical(action_probs)        
        action = action_distribution.sample()
        # print("------action_distribution=",action_distribution,"-----action=",action)
        print("------action_probs=",action_probs[0],"-----action=",action,"---action.item()=",action.item())
        log_prob = action_distribution.log_prob(action)
        aindex=action.detach().numpy()[0]
        aprobs=action_probs.detach().numpy()[0]
        print("--------aindex=",aindex,"----aprobs=",aprobs)
        my_log_prob=np.log(aprobs[aindex])
        print("----my_log_prob=",my_log_prob,"is equal is: log_prob=",log_prob)
        # 执行动作
        next_state, reward, done, truncated, _ = env.step(action.item())
        total_reward += reward
        print("------total_reward=",total_reward,"----done=",done,"-----truncated=",truncated)
        # 记录log_prob和奖励
        log_probs.append(log_prob)
        rewards.append(reward)
        state = next_state
        done = done or truncated
    episode_rewards.append(total_reward)
    # 计算每一步的折扣回报（return）
    returns = []
    G = 0
    for r in reversed(rewards):
        G = r + gamma * G
        returns.insert(0, G)
    returns = torch.tensor(returns, dtype=torch.float32).to('cpu')
    # 为了稳定训练，对returns进行归一化处理
    returns = (returns - returns.mean()) / (returns.std() + 1e-8)
    # 计算损失：每一步的损失为 -log_prob * return
    loss = 0
    for log_prob, G in zip(log_probs, returns):
        loss += -log_prob * G
    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    print(f"Episode {episode + 1}, Total Reward: {int(total_reward)}")

env.close()

# 保存训练好的模型参数
torch.save(policy_net.state_dict(), 'cartpole_PG_model.pth')

# 绘制每个episode的总奖励曲线
plt.figure(figsize=(10, 5))
plt.plot(range(1, num_episodes + 1), episode_rewards, label='Total Reward per Episode')
plt.xlabel('Episode')
plt.ylabel('Total Reward')
plt.title('Policy Gradient on CartPole-v1')
plt.legend()
plt.show()


import torch
from torch.distributions import Categorical
probs = torch.tensor([4.0,3.0,2.0,1.0])
pd = Categorical(probs=probs)
print(pd.probs)  # tensor([0.4000, 0.3000, 0.2000, 0.1000])

action_distribution = torch.distributions.Categorical(pd.probs)   
print("-------action_distribution=",action_distribution)
action = action_distribution.sample()
log_probs = action_distribution.log_prob(action)
print("-------action=",action,"---------log_probs=",log_probs)
real_probs=log_probs.exp() # inverse of Logarithmic probability
print("log_probs=",log_probs,"====real_probs=",real_probs)
# print("-------action=",action,"---------log_prob=",log_prob)
# # 计算索引为 [0, 2] 的元素的对数概率

# probs = torch.tensor([0.4,0.3,0.2,0.1])
# pd = Categorical(probs=probs)
# print(pd.probs)  # tensor([0.4000, 0.3000, 0.2000, 0.1000])
# https://blog.csdn.net/qq_37388085/article/details/127251550


# probs = torch.tensor([0.1, 0.3, 0.6]) 
# # 创建 Categorical 对象
# dist = Categorical(probs=probs)
# print("-----dist=",dist)
# log_probs = dist.log_prob(torch.tensor([0, 2]))
# real_probs=log_prob.exp()
# print("log_probs=",log_probs,"====real_probs=",real_probs)